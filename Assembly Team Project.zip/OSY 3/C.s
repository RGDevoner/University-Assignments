.text
.globl __start

main: 
    la $t0, pin
    li $t4, 10   
    li $v0, 4
    la $a0, str
    syscall
    jal readPin
    li $v0, 10
    syscall

readPin: #A
    bge $t2, $t4, createSparse

    li $v0, 4
    la $a0, p1
    syscall

    move $a0, $t2
    li $v0, 1
    syscall

    li $v0, 4
    la $a0, p2
    syscall

    li $v0, 5
    syscall
    sw $v0, ($t0) 

    addi $t0, $t0, 4  
    addi $t2, $t2, 1  
    j readPin   

createSparse: #B
    la $t0, pin
    la $t1, Sparse
    li $t9, 0
    li $t2, 0
    li $t4, 10 
    cs: 
        bge $t2, $t4, exit
        lw $t3, 0($t0)
        bnez $t3, saveSparse
        j skipSaveSparse

    saveSparse: 
        li $v0, 4
        la $a0, p1
        syscall

        move $a0, $t2
        li $v0, 1
        syscall

        li $v0, 4
        la $a0, p3
        syscall

        li $v0, 1
        move $a0, $t3
        syscall

        li $v0, 4
        la $a0, p4
        syscall
		sw $t3, ($t1)
        addi $t1, $t1, 4
        sw $t3, ($t1)
        addi $t1, $t1, 4
        addi $t9, $t9, 1

    skipSaveSparse:
        addi $t0, $t0, 4
        addi $t2, $t2, 1
        j cs

exit:
    # Εκτύπωση του πίνακα Sparse
    jal printSparsePositions

    move $v0, $t9
    jr $ra

printSparsePositions:
    la $t1, Sparse    # Φορτώνουμε τη διεύθυνση του πίνακα Sparse
    li $t2, 0         # Αρχικοποιούμε τον μετρητή του πίνακα Sparse
    li $v0, 4         # Κωδικός υπηρεσίας εκτύπωσης (print string)
printSparsePositionsLoop:
    bge $t2, $t9, exitPrintSparsePositions  # Έξοδος αν έχουμε εκτυπώσει όλες τις θέσεις

    li $v0, 4          # Κωδικός υπηρεσίας εκτύπωσης (print string)
    la $a0, p5         # Φορτώνουμε το μήνυμα " Value: " στον $a0
    syscall

    move $a0, $t1     # Φορτώνουμε την τρέχουσα τιμή του Sparse στον $a0
    li $v0, 1          # Κωδικός υπηρεσίας εκτύπωσης ακέραιου (print integer)
    syscall

	li $v0, 4          # Κωδικός υπηρεσίας εκτύπωσης (print string)
    la $a0, p3         # Φορτώνουμε το μήνυμα " Value: " στον $a0
    syscall

    li $v0, 4          # Κωδικός υπηρεσίας εκτύπωσης (print string)
    la $a0, p4         # Φορτώνουμε το μήνυμα " \n" στον $a0
    syscall

    addi $t1, $t1, 4  # Αυξάνουμε τη διεύθυνση του πίνακα Sparse κατά 4 bytes
    addi $t2, $t2, 1  # Αυξάνουμε τον μετρητή του πίνακα Sparse
    j printSparsePositionsLoop

exitPrintSparsePositions:
    jr $ra

.data
pin: .space 40
Sparse: .space 80
p1: .asciiz "Position "
p2: .asciiz " :"
p3: .asciiz " Value: "
p4: .asciiz " \n"
p5: .asciiz "Position : "
str: .asciiz "Reading array A \n"