
/*#include "gameobject.h"
#include "gamestate.h"
#include "player.h"

#include "util.h"
#include "enemy.h"
#include <cmath>
#include <thread>
#include <chrono>
#include< cstdlib >
void Enemy::update(float dt)
{
	float minx = 5.0f;
	float maxx = 9.8f;
	float speed = 2.0f;


}



void Enemy::draw()
{

	graphics::drawRect(positionx + m_state->m_global_offset_x, positiony + m_state->m_global_offset_y,size,size, m_brush_enemy);
	m_brush_enemy.fill_opacity = 1.0f;
	m_brush_enemy.outline_opacity = 0.0f;
}

void Enemy::init()
{
	// stage 1
	float positionx = 5.0f;
	float positiony = 5.0f;

	m_brush_enemy.texture = m_state->getFullAssetPath("transformation alex.png");

	




	// Adjust width for finer collision detection
	m_width = 0.5f;


}

void Enemy::debugDraw()
{

	graphics::Brush debug_brush;
	SETCOLOR(debug_brush.fill_color, 1, 0.3f, 0);
	SETCOLOR(debug_brush.outline_color, 1, 0.1f, 0);
	debug_brush.fill_opacity = 0.1f;
	debug_brush.outline_opacity = 1.0f;
	graphics::drawRect(m_state->getCanvasWidth() * 0.5f, m_state->getCanvasHeight() * 0.5f, m_width, m_height, debug_brush);

	char s[20];
	sprintf_s(s, "(%5.2f, %5.2f)", m_pos_x, m_pos_y);


	SETCOLOR(debug_brush.fill_color, 1, 0, 0);
	debug_brush.fill_opacity = 1.0f;
	graphics::drawText(m_state->getCanvasWidth() * 0.5f - 0.4f, m_state->getCanvasHeight() * 0.5f - 0.6f, 0.15f, s, debug_brush);


}
void Enemy::moveEnemy(float dt)
{

	float delta_time = dt / 1000.0f;

	// Stage 2 code: Acceleration-based velocity
	float move = 0.0f;

	




}*/