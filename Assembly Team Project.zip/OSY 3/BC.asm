		.text
		.globl __start

main: 
		la $t0, pin
		li $t4, 10   
		li $v0, 4
		la $a0, str
		syscall
		jal readPin

    	la $a0,strSparse #prints Displaying Sparse Array A
		li $v1,4
		syscall
		
		la $a0,Sparse #base register
		move $a1,$v0 #size
		
		jal printSparse
		
		li $v0,10
		syscall

printSparse:

		li $t0,1
		move $t1,$a0 
		lw $t2,($t1)			#loads first data of array
		
loop:	

		la $a0,p1_2			#prints Position
		li $v0,4
		syscall
		
		move $a0,$t2		
		li $v0,1
		syscall
		
		add $t1,$t1,4		#gets the item
		lw $t2,($t1)
		
		la $a0,p3			#prints Item
		li $v0,4
		syscall
		
		move $a0,$t2
		li $v0,1
		syscall
		
		add $t0,$t0,2		#gets next position
		add $t1,$t1,4
		lw $t2,($t1)
		
		la $a0,p4
		li $v0,4
		syscall
		
		blt $t0,$a1,loop 
		
		jr $ra

readPin: #A
		bge $t2, $t4, createSparse

		li $v0, 4
		la $a0, p1
		syscall

		move $a0, $t2
		li $v0, 1
		syscall

		li $v0, 4
		la $a0, p2
		syscall

		li $v0, 5
		syscall
		sw $v0, ($t0) 

		addi $t0, $t0, 4  
		addi $t2, $t2, 1  

		j readPin   

createSparse: #B
		la $t0, pin
		la $t1, Sparse
		li $t9, 0
		li $t2, 0
		li $t4, 10 
cs: 
		bge $t2, $t4, exit
		lw $t3, 0($t0)
		bnez $t3, saveSparse
		j skipSaveSparse

saveSparse: 

		addi $t1, $t1, 4
		sw $t3, ($t1)
		addi $t1, $t1, 4
		addi $t9, $t9, 1

skipSaveSparse:
		addi $t0, $t0, 4
		addi $t2, $t2, 1
		j cs

exit:

		move $v0, $t9
		jr $ra

		.data
		
pin: .space 40
Sparse: .space 80
p1: .asciiz "Position "
p1_2: .asciiz "Position: "
p2: .asciiz " :"
p3: .asciiz " Value: "
p4: .asciiz " \n"
str: .asciiz "Reading array A \n"
strSparse:   .asciiz "Displaying Sparse Array A\n"