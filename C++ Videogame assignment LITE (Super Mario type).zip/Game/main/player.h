#pragma once
#include "gamestate.h"
#include "gameobject.h"
#include <sgg/graphics.h>
#include "box.h"


class Player : public Box, public GameObject
{
	// animated player
	std::vector<std::string> m_sprites;

	graphics::Brush m_brush_player;

	const float m_accel_horizontal = 7.0f;
	const float m_accel_vertical = 210.1f;
	const float m_max_velocity = 5.0f;
	const float m_gravity = 10.0f;
public:
	float m_vx = 0.0f;
	float m_vy = 0.0f;
	int l2 = 0;

public:
	void update(float dt) override;
	void draw() override;
	void init() override;
	void die();
	void respawn();
	void Lvl2();
	void fin();	
	Player(std::string name) : GameObject(name) {}

	bool facingRight; // Metavliti katefthinsis paixti


protected:
	void debugDraw();

	
	void movePlayer(float dt);




};


    

    

  


