#include "player.h"
#include "util.h"
#include <cmath>
#include <thread>
#include <chrono>
#include< cstdlib >
void Player::update(float dt)
{
	float delta_time = dt / 1000.0f;
	

	movePlayer(dt);
	
	
	m_state->m_global_offset_x = m_state->getCanvasWidth() / 2.0f - m_pos_x;
	m_state->m_global_offset_y = m_state->getCanvasHeight() / 2.0f - m_pos_y;
	if (m_pos_y > 45.0f) { 
		respawn(); // ������������ ��� ������ ��� ���� spawn
	}
	if (m_pos_x >61.0f && m_pos_x<70.0f ) {
		
		Lvl2();
	}
	if ( (m_pos_x > 34.0f && m_pos_x<34.1f) && (m_pos_y==9.0f)) {
		respawn();
	}
	GameObject::update(dt);
	if (m_pos_x > 120.0f) {
		
		graphics::playSound(m_state->getFullAssetPath("Evil.wav"), 0.5f);
		fin();
	}
	
	
}
void Player::fin() {
	
	m_pos_x = 110.0f;
	m_pos_y = 40.0f;
	m_vx = 0.0f;
	m_vy = 0.0f;
	int i = 0;
	
	std::this_thread::sleep_for(std::chrono::seconds(3));
	graphics::playSound(m_state->getFullAssetPath("ssj.wav"), 0.4f);
	graphics::playSound(m_state->getFullAssetPath("TRUE.wav"), 1.0f);
	for (i = 0; i < 10; i++) {
		m_sprites.push_back(m_state->getFullAssetPath("rnd default pic.png"));

	}
	for (i = 0; i < 1000; i++) {
		m_sprites.push_back(m_state->getFullAssetPath("rnd moving.png"));

		
	}
	
	
	

}
void Player::respawn() 
{
	// Epanafora toy paixti stin thesi spawn
	m_pos_x = 5.0f;
	m_pos_y = 5.0f;
	m_vx = 0.0f;
	m_vy = 0.0f;
	graphics::playSound(m_state->getFullAssetPath("OUCH.wav"), 0.2f);
	
}
void Player::Lvl2() {
	
	m_pos_x = 100.0f;
	m_pos_y = 4.0f;
	m_vx = 0.0f;
	m_vy = 0.0f;
	graphics::playSound(m_state->getFullAssetPath("Portal.wav"), 0.5f);
	
}
void Player::die() {
	
	exit(EXIT_SUCCESS);
}

void Player::draw()
{
	
	int sprite = (int)fmod(1000.0f - m_pos_x * 1.7f, m_sprites.size());//allagi  kare animation taxitita
	if (facingRight == true) {
		graphics::setScale(1.0f, 1.0f); // �������� �������

	}
	else {
		graphics::setScale(-1.0f, 1.0f); // ���������� ���� ����� X

	}
	m_brush_player.texture = m_sprites[sprite];
	
	

	graphics::drawRect(m_state->getCanvasWidth() * 0.5f, m_state->getCanvasHeight() * 0.5f, 1.0f, 1.0f, m_brush_player);
	int spriteIndex = (int)fmod(1000.0f - m_pos_x * 1.7f, m_sprites.size());
	m_brush_player.texture = m_sprites[spriteIndex];
	
	if (m_state->m_debugging)
		debugDraw();
}

void Player::init()
{
	// stage 1
	m_pos_x = 5.0f;
	m_pos_y = 5.0f;

	m_state->m_global_offset_x = m_state->getCanvasWidth() / 2.0f - m_pos_x;
	m_state->m_global_offset_y = m_state->getCanvasHeight() / 2.0f - m_pos_y;

	m_brush_player.fill_opacity = 1.0f;
	m_brush_player.outline_opacity = 0.0f;
	
	if (m_pos_x > 0.f) {
		m_sprites.push_back(m_state->getFullAssetPath("ALEX moving 1.png"));
		m_sprites.push_back(m_state->getFullAssetPath("alex moving 2.png"));
		m_sprites.push_back(m_state->getFullAssetPath("alex moving 3.png"));
		m_sprites.push_back(m_state->getFullAssetPath("alex moving 4.png"));
	}
	

		
	
	
	m_width = 0.5f;
	
	
}

void Player::debugDraw()
{
	
	graphics::Brush debug_brush;
	SETCOLOR(debug_brush.fill_color, 1, 0.3f, 0);
	SETCOLOR(debug_brush.outline_color, 1, 0.1f, 0);
	debug_brush.fill_opacity = 0.1f;
	debug_brush.outline_opacity = 1.0f;
	graphics::drawRect(m_state->getCanvasWidth() * 0.5f, m_state->getCanvasHeight() * 0.5f, m_width, m_height, debug_brush);
	
	char s[20];
	sprintf_s(s, "(%5.2f, %5.2f)", m_pos_x, m_pos_y);
	
	
	SETCOLOR(debug_brush.fill_color, 1, 0, 0);
	debug_brush.fill_opacity = 1.0f;
	graphics::drawText(m_state->getCanvasWidth() * 0.5f - 0.4f, m_state->getCanvasHeight() * 0.5f - 0.6f, 0.15f, s, debug_brush);
	
	
}
void Player::movePlayer(float dt)
{
	
	float delta_time = dt / 1000.0f;

	
	float move = 0.0f;
	
	if (graphics::getKeyState(graphics::SCANCODE_A)) {
		facingRight = false;
		

		move -= 10.0f;//taxitita 
	}
	if (graphics::getKeyState(graphics::SCANCODE_D)) {
		
		facingRight = true;
		 
		move = 10.0f;
		
	}
	if (graphics::getKeyState(graphics::SCANCODE_SPACE)) {
		
		graphics::playSound(m_state->getFullAssetPath("FemJump.wav"), 0.05f);
	}
	
	
	m_vx = std::min<float>(m_max_velocity, m_vx + delta_time * move * m_accel_horizontal);
	m_vx = std::max<float>(-m_max_velocity, m_vx);


	m_vx -= 0.2f * m_vx / (0.1f + fabs(m_vx));

	
	if (fabs(m_vx) < 0.01f) {
		m_vx = 0.0f;
		
	}
	
	m_pos_x += m_vx * delta_time;

	
	if (m_vy == 0.0f) {
		m_vy -= (graphics::getKeyState(graphics::SCANCODE_SPACE) ? m_accel_vertical : 0.0f) * 0.02f;// not delta_time!! Burst 
		
	}
	// add gravity
	m_vy += delta_time * m_gravity;

	// adjust vertical position
	m_pos_y += m_vy * delta_time;


}


