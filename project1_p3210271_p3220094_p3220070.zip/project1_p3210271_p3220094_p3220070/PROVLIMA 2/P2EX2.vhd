library IEEE;
use IEEE.STD_LOGIC_1164.all;
ENTITY P2EX2 is
PORT (x1,x2,x3,x4: IN STD_LOGIC;
			f : OUT STD_LOGIC );
END P2EX2;
ARCHITECTURE func OF P2EX2 IS
BEGIN
	f<=(x1 or x3 or x4) and (x1 or not x3 or not x4) and (not x1 or x3 or not x4) and (not x1 or x2 or not x3 or x4);
END func;