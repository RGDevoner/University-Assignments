#Alexandros Makrygiannis p3210271
.text
.globl __start

main:
	la $a0, warnin
	li $v0, 4
	syscall #print megisti timi n kai k poy mporei na parei
	la $a0, str1 
	li $v0, 4
	syscall #Print "Enter number of objects in the set (n): "

	li $v0, 5
	syscall

	sw $v0, n
	lw $a0, n
	li $v0, 1 #read n
	

	la $a0, str2
	li $v0, 4
	syscall	# Print "Enter number to be chosen (k): " 
	
	li $v0, 5
	syscall

	sw $v0, k
	lw $a0, k
	li $v0, 1	#read n
	
	li $t0,13
	sw $t0,gg
	lw $t1, n
	
	lw $t2, k
	
	
	ble $t0,$t2, cancel #overflow 
	ble $t0,$t1,cancel  #overflow 
	ble $t2, $t1, c2 # if n>=k goto c2 
	j c1
	
	
c1: # thats the else of above
	la $a0, mess
	li $v0, 4
	syscall
	li $v0,10
	syscall #print "Please enter n >= k >= 0" and end the program

c2:
	
	ble $t1, $0, c3 #if k>=0 goto c3

c3:
	li $t3, 1
	sw $t3, i #i=1
	li $t4, 1
	sw $t4, Factorial_n	#Factorial_n=1
	
again1:#loop
	bgt $t3, $t1, c4	#if notloop go to c4

	mul $t4, $t4, $t3	#Factorial_n=Factorial_n*i
	sw $t4, Factorial_n
	
	add $t3, $t3, 1 #i=i+1
	sw $t3, i
	j again1 #repeat loop
	
c4:
	li $t3, 1
	sw $t3, i # i=1
	li $t5, 1
	sw $t5, Factorial_k # Factorial_k=1
again2:#loop
	bgt $t3, $t2, c5 #if notloop goto c5

	mul $t5, $t5, $t3 #Factorial_k=Factorial_k*i
	
	sw $t5, Factorial_k 
	add $t3, $t3, 1 #i=i+1
	sw $t3, i
	j again2	#repeat loop
c5:
	li $t3, 1
	sw $t3, i  #i=1
	li $t7, 1
	sw $t7, Factorial_n_k #Factorial_n_k=1
	li $t6, 0
	lw $t6,d #d=0
	sub $t6,$t1,$t2 #d=n-k
	
	
	again3: #loop
	bgt $t3, $t6, exit1 #if not loop goto exit1

	mul $t7, $t7, $t3 #Factorial_n_k=Factorial_n_k*i
	
	sw $t7, Factorial_n_k
	add $t3, $t3, 1 #i=i+1
	sw $t3, i
	j again3 #repeat loop
exit1:
	li $t8, 1
	sw $t8, mf #mf=1
	mul $t8,$t7,$t5 # mf=Factorial_n_k*Factorial_k
	li $t9,1
	sw $t9,fn #fn=1
	div $t9,$t4,$t8 #fn=Factorial_n/d
	sw $t9,fn
	la $a0,gmess #print "C("
	li $v0, 4
	syscall 
	lw $a0,n #print n
	li $v0,1
	syscall
	
	la $a0,g1 #print ", "
	li $v0, 4
	syscall
	lw $a0,k #print k
	li $v0,1
	syscall
	la $a0,g2 #print ") = "
	li $v0, 4
	syscall
	lw $a0,fn # print fn
	li $v0,1
	syscall
	
	li $v0,10
	syscall
cancel:
	la $a0, ff #prints cancel message
	li $v0, 4
	syscall
	li $v0,10
	syscall
	
.data
str1: .asciiz "Enter number of objects in the set (n): " # String str1="Enter number of objects in the set (n): 
n: .word 0
str2: .asciiz "Enter number to be chosen (k): "
k: .word 0
mess: .asciiz "Please enter n >= k >= 0"
Factorial_n: .word 1  #arxikopoisi metavliton olon otan exei to .word einai int me tin timi dipla otan .asciiz einai string me afto poy emfanizei meta
Factorial_k: .word 1
Factorial_n_k: .word 1
d: .word 0
i: .word 1
gmess: .asciiz "C("
g1: .asciiz ", "
mf: .word 0
fn: .word 0
g2: .asciiz ") = "
warnin: .asciiz "Max capacity of n and k : 12!\n"
ff: .asciiz " You surpassed the max capacity of n or/and k !"
gg: .word 13