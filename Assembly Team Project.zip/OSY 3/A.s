.text
.globl __start

main: 
    la $t0, pin
    li $t4, 10   
	li $v0, 4
    la $a0, str
    syscall
readPin:
    bge $t2, $t4, exit  

    li $v0, 4
    la $a0, p1
    syscall

    move $a0, $t2
    li $v0, 1
    syscall

    li $v0, 4
    la $a0, p2
    syscall

    li $v0, 5
    syscall
    sw $v0, ($t0) 

    addi $t0, $t0, 4  
    addi $t2, $t2, 1  

    j readPin   

exit:
  
    li $v0, 10
    syscall

.data
pin: .space 40
p1:  .asciiz "Position "
p2:  .asciiz " :"
str: .asciiz "Reading array A \n"