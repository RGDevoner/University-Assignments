#include "level.h"
#include <sgg/graphics.h>
#include "player.h"
#include "util.h"
#include "enemy.h"
#include "gamestate.h"
#include "gameobject.h"


void Level::drawBlock(int i)
{
	Box& box = m_blocks[i];
	std::string& name = m_block_names[i];

	float x = box.m_pos_x + m_state->m_global_offset_x;
	float y = box.m_pos_y + m_state->m_global_offset_y;

	m_block_brush.texture = m_state->getFullAssetPath(name);

	graphics::drawRect(x, y, 1.0f * m_block_size, 1.0f * m_block_size, m_block_brush);

	if (m_state->m_debugging)
		graphics::drawRect(x, y, m_block_size, m_block_size, m_block_brush_debug);

	
}

void Level::checkCollisions()
{
	
	

	for (auto& block : m_blocks)
	{
		float offset = 0.0f;
		if (offset = m_state->getPlayer()->intersectDown(block))
		{
			
			m_state->getPlayer()->m_pos_y += offset;
			

			// add sound event
			if (m_state->getPlayer()->m_vy > 1.0f)
				
			graphics::playSound(m_state->getFullAssetPath("GroundSound.wav"), 0.05f);
			m_state->getPlayer()->m_vy = 0.0f;

			break;
		}
	}

	for (auto& block : m_blocks)
	{
		float offset = 0.0f;
		if (offset = m_state->getPlayer()->intersectSideways(block))
		{
			
			m_state->getPlayer()->m_pos_x += offset;

			m_state->getPlayer()->m_vx = 0.0f; 
			if (offset==34.f){
				m_state->getPlayer()->m_pos_x = m_center_x;
				m_state->getPlayer()->m_pos_y = m_center_y;
				break;
			}
			
			break;
		}

	}



}




void Level::update(float dt)
{
	if (m_state->getPlayer()->isActive())
		m_state->getPlayer()->update(dt);
	//if(m_state->getEnemy()->isActive())
		//m_state->getEnemy()->update(dt);
	checkCollisions();

	GameObject::update(dt);
	
		//spawnEnemy();

		
}

void Level::draw()
{
	float w = m_state->getCanvasWidth();
	float h = m_state->getCanvasHeight();
	
	float offset_x = m_state->m_global_offset_x / 2.0f + w / 2.0f;
	float offset_y = m_state->m_global_offset_y / 2.0f + h / 2.0f;

	//draw background
	graphics::drawRect(1.3f*offset_x, offset_y, 8.0f * w, 8.0f * w, m_brush_background);
	
	// draw player
	if (m_state->getPlayer()->isActive())
		m_state->getPlayer()->draw();
	//if (m_state->getEnemy()->isActive())
		//m_state->getEnemy()->draw();
	
	// draw blocks

	for (int i = 0; i < m_blocks.size(); i++)
	{
		drawBlock(i);
	}
	//if (m_state->getEnemy()->isActive())
	//	m_state->getEnemy()->draw();
	
	
}

void Level::init()
{
	//m_enemy = new Enemy("Enemy");
	//Enemy("Enemy1");
	//m_enemy->init();
	//m_enemy->setPosition(5.0f, 5.0f);
	// Stage 1
	for (auto p_gob : m_static_objects)
		if (p_gob) p_gob->init();

	for (auto p_gob : m_dynamic_objects)
		if (p_gob) p_gob->init();
	
	graphics::playSound(m_state->getFullAssetPath("Elysium.wav"), 0.1f);
	
	//m_enemy = new Enemy("Enemy1");
	//m_enemy->init();
	//m_enemy->setPosition(5.0f, 5.0f);
	
	
	m_blocks.push_back(Box(4, 7, 1, 1));
	m_blocks.push_back(Box(5, 7, 1, 1));
	m_blocks.push_back(Box(6, 7, 1, 1));
	m_blocks.push_back(Box(7, 7, 1, 1));
	m_blocks.push_back(Box(8, 7, 1, 1));
	m_blocks.push_back(Box(9, 7, 1, 1));//finish first platform 
	m_blocks.push_back(Box(11, 7, 1, 1));
	m_blocks.push_back(Box(13, 7, 1, 1));
	m_blocks.push_back(Box(14, 7, 1, 1));//first enemie start
	m_blocks.push_back(Box(14, 8, 1, 1));
	m_blocks.push_back(Box(15, 8, 1, 1));
	m_blocks.push_back(Box(16, 8, 1, 1));
	m_blocks.push_back(Box(17, 8, 1, 1));
	m_blocks.push_back(Box(18, 8, 1, 1));
	m_blocks.push_back(Box(19, 8, 1, 1));
	m_blocks.push_back(Box(20, 7, 1, 1));//first enemie finish 
	m_blocks.push_back(Box(20, 8, 1, 1));
	m_blocks.push_back(Box(21, 8, 1, 1));
	m_blocks.push_back(Box(21, 9, 1, 1));
	m_blocks.push_back(Box(22, 9, 1, 1));
	m_blocks.push_back(Box(26, 10, 1, 1));
	m_blocks.push_back(Box(28, 10, 1, 1));
	m_blocks.push_back(Box(30, 10, 1, 1));
	m_blocks.push_back(Box(30, 9, 1, 1));//extros 2 start
	m_blocks.push_back(Box(31, 10, 1, 1));
	m_blocks.push_back(Box(32, 10, 1, 1));
	m_blocks.push_back(Box(33, 10, 1, 1));
	m_blocks.push_back(Box(34, 10, 1, 1));
	m_blocks.push_back(Box(35, 10, 1, 1));
	m_blocks.push_back(Box(36, 10, 1, 1));
	m_blocks.push_back(Box(37, 10, 1, 1));
	m_blocks.push_back(Box(38, 10, 1, 1));
	m_blocks.push_back(Box(38, 9, 1, 1));//extros 2 end
	m_blocks.push_back(Box(40, 8, 1, 1));//skala start
	m_blocks.push_back(Box(41, 7, 1, 1));
	m_blocks.push_back(Box(42, 6, 1, 1));
	m_blocks.push_back(Box(43, 5, 1, 1));
	m_blocks.push_back(Box(41, 8, 1, 1));
	m_blocks.push_back(Box(42, 7, 1, 1));
	m_blocks.push_back(Box(43, 6, 1, 1));
	m_blocks.push_back(Box(44, 5, 1, 1));//skala finish 
	m_blocks.push_back(Box(45, 6, 1, 1));//skala down start
	m_blocks.push_back(Box(47, 7, 1, 1));
	m_blocks.push_back(Box(49, 8, 1, 1));
	m_blocks.push_back(Box(50, 10, 1, 1));
	m_blocks.push_back(Box(51, 10, 1, 1));
	m_blocks.push_back(Box(52, 10, 1, 1));
	m_blocks.push_back(Box(53, 10, 1, 1));
	m_blocks.push_back(Box(54, 10, 1, 1));
	m_blocks.push_back(Box(55, 10, 1, 1));
	m_blocks.push_back(Box(56, 10, 1, 1));
	m_blocks.push_back(Box(57, 10, 1, 1));
	m_blocks.push_back(Box(58, 10, 1, 1));
	m_blocks.push_back(Box(59, 10, 1, 1));
	m_blocks.push_back(Box(60, 10, 1, 1));
	m_blocks.push_back(Box(61, 10, 1, 1));
	m_blocks.push_back(Box(62, 10, 1, 1));
	m_blocks.push_back(Box(62, 9, 1, 1));//portal for next lvl or finish block 
										//lvl 2
	m_blocks.push_back(Box(100, 6, 1, 1));
	m_blocks.push_back(Box(101, 6, 1, 1));
	m_blocks.push_back(Box(102, 6, 1, 1));
	
	m_blocks.push_back(Box(104, 6, 1, 1));
	m_blocks.push_back(Box(106, 6, 1, 1));
	m_blocks.push_back(Box(108, 6, 1, 1));
	m_blocks.push_back(Box(110, 7, 1, 1));
	m_blocks.push_back(Box(108, 9, 1, 1));
	m_blocks.push_back(Box(106, 11, 1, 1));
	m_blocks.push_back(Box(106, 13, 1, 1));
	m_blocks.push_back(Box(104, 11, 1, 1));
	m_blocks.push_back(Box(102, 13, 1, 1));
	m_blocks.push_back(Box(100, 13, 1, 1));
	m_blocks.push_back(Box(98, 13, 1, 1));
	m_blocks.push_back(Box(95, 13, 1, 1));
	m_blocks.push_back(Box(94, 13, 1, 1));
	m_blocks.push_back(Box(93, 13, 1, 1));
	m_blocks.push_back(Box(92, 13, 1, 1));
	m_blocks.push_back(Box(91, 13, 1, 1));
	m_blocks.push_back(Box(90, 13, 1, 1));//20
	m_blocks.push_back(Box(88, 15, 1, 1));
	m_blocks.push_back(Box(86, 14, 1, 1));
	m_blocks.push_back(Box(84, 14, 1, 1));
	m_blocks.push_back(Box(82, 15, 1, 1));
	m_blocks.push_back(Box(80, 18, 1, 1));
	m_blocks.push_back(Box(78, 18, 1, 1));//mod
	m_blocks.push_back(Box(79, 18, 1, 1));
	m_blocks.push_back(Box(80, 18, 1, 1));
	m_blocks.push_back(Box(81, 18, 1, 1));
	m_blocks.push_back(Box(82, 18, 1, 1));
	m_blocks.push_back(Box(83, 17, 1, 1));
	m_blocks.push_back(Box(83, 18, 1, 1));
	m_blocks.push_back(Box(88, 18, 1, 1));
	m_blocks.push_back(Box(84, 18, 1, 1));
	m_blocks.push_back(Box(85, 18, 1, 1));
	m_blocks.push_back(Box(86, 18, 1, 1));
	m_blocks.push_back(Box(87, 18, 1, 1));//mod
	m_blocks.push_back(Box(88, 18, 1, 1));
	m_blocks.push_back(Box(89, 18, 1, 1));
	m_blocks.push_back(Box(91, 17, 1, 1));
	m_blocks.push_back(Box(90, 18, 1, 1));
	m_blocks.push_back(Box(91, 18, 1, 1));
	m_blocks.push_back(Box(93, 18, 1, 1));
	m_blocks.push_back(Box(95, 18, 1, 1));
	m_blocks.push_back(Box(97, 18, 1, 1));
	m_blocks.push_back(Box(99, 18, 1, 1));
	m_blocks.push_back(Box(101, 18, 1, 1));
	m_blocks.push_back(Box(103, 18, 1, 1));
	m_blocks.push_back(Box(106, 18, 1, 1));
	m_blocks.push_back(Box(104, 20, 1, 1));
	m_blocks.push_back(Box(106, 22, 1, 1));
	m_blocks.push_back(Box(104, 24, 1, 1));
	m_blocks.push_back(Box(106, 26, 1, 1));
	m_blocks.push_back(Box(104, 28, 1, 1));
	m_blocks.push_back(Box(106, 30, 1, 1));
	m_blocks.push_back(Box(104, 32, 1, 1));
	m_blocks.push_back(Box(106, 34, 1, 1));
	m_blocks.push_back(Box(106, 36, 1, 1));
	m_blocks.push_back(Box(104, 36, 1, 1));
	m_blocks.push_back(Box(105, 33, 1, 1));
	m_blocks.push_back(Box(103, 33, 1, 1));
	
	m_blocks.push_back(Box(107, 33, 1, 1));
	m_blocks.push_back(Box(104, 33, 1, 1));
	m_blocks.push_back(Box(106, 33, 1, 1));
	m_blocks.push_back(Box(108, 33, 1, 1));
	m_blocks.push_back(Box(110, 33, 1, 1));
	m_blocks.push_back(Box(112, 33, 1, 1));
	m_blocks.push_back(Box(114, 33, 1, 1));
	m_blocks.push_back(Box(116, 33, 1, 1));
	m_blocks.push_back(Box(118, 33, 1, 1));
	m_blocks.push_back(Box(119, 33, 1, 1));
	m_blocks.push_back(Box(120, 33, 1, 1));
	m_blocks.push_back(Box(121, 33, 1, 1));

	m_blocks.push_back(Box(121, 33, 1, 1));
	m_blocks.push_back(Box(110, 41, 1, 1));
	m_blocks.push_back(Box(111, 41, 1, 1));
	m_blocks.push_back(Box(112, 41, 1, 1));
	m_blocks.push_back(Box(113, 41, 1, 1));
	m_blocks.push_back(Box(114, 41, 1, 1));
	m_blocks.push_back(Box(114, 41, 1, 1));
	m_blocks.push_back(Box(115, 41, 1, 1));
	m_blocks.push_back(Box(116, 41, 1, 1));
	m_blocks.push_back(Box(117, 41, 1, 1));
	m_blocks.push_back(Box(118, 41, 1, 1));
	
	
	m_blocks.push_back(Box(-9, -9, 1, 1));
	m_blocks.push_back(Box(-10, -9, 1, 1));
	m_blocks.push_back(Box(-11, -9, 1, 1));
	m_blocks.push_back(Box(-12, -9, 1, 1));





	m_block_names.push_back("A.png");//instr
	m_block_names.push_back("SPACE.png");//instr
	m_block_names.push_back("D.png");//instuctions 
	
	
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("db.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("db.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("db.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("db.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("renb.png");
	m_block_names.push_back("GLVL2.png");//final block
	m_block_names.push_back("yb.png");//lvl 2
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("yb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");
	m_block_names.push_back("pb.png");

	


	



	

	m_block_brush.outline_opacity = 0.0f;
	m_block_brush_debug.fill_opacity = 0.1f;
	SETCOLOR(m_block_brush_debug.fill_color, 0.1f, 1.0f, 0.1f);
	SETCOLOR(m_block_brush_debug.outline_color, 0.3f, 1.0f, 0.2f);
}

Level::Level(const std::string& name)
	: GameObject(name)
{
	m_brush_background.outline_opacity = 1.0f;
	m_brush_background.texture = m_state->getFullAssetPath("bg.png");
	

}

Level::~Level()
{
	for (auto p_go : m_static_objects)
		delete p_go;
	for (auto p_go : m_dynamic_objects)
		delete p_go;
}