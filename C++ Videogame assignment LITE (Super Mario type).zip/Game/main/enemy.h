/*#pragma once

#include <sgg/graphics.h>
#include "gamestate.h"
#include "gameobject.h"
#include "box.h"
#include "enemy.h"


class Enemy : public Box, public GameObject
{
	// animated player
	std::vector<std::string> m_sprites;
	float velocity = 0.0f;
	graphics::Brush m_brush_enemy;
	float size = 1.0f;
	float positionx;
	float positiony;
	const float m_accel_horizontal = 7.0f;
	const float m_accel_vertical = 210.1f;
	const float m_max_velocity = 5.0f;
	const float m_gravity = 10.0f;
public:
	float m_vx = 0.0f;
	float m_vy = 0.0f;
	int l2 = 0;
	void setPosition(float x, float y) {
		positionx = x;
		positiony = y;
	}
public:
	 void update(float dt);
	 void draw() ;
	void init() ;
	float getPositionX() const { return positionx; }
	float getPositionY() const { return positiony; }
	float getWidth() const {
		return size;
	}
	float getHeight() const {
		return size;
	}

	Enemy(std::string name2) : GameObject(name2) {}

	

protected:
	void debugDraw();

	// dynamic motion control
	void moveEnemy(float dt);




};*/