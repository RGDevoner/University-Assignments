		.text
		.globl __start

__start:
		
		jal readOption
		
		move $a0,$v0
		
		li $v0,10
		syscall
		
		
readOption:
		
		la $a0,Space1
		li $v0,4
		syscall
		
		la $a0,ReadArrayA
		li $v0,4
		syscall
		
		la $a0,ReadArrayB
		li $v0,4
		syscall
		
		la $a0,CreateSpArA
		li $v0,4
		syscall
		
		la $a0,CreateSpArB
		li $v0,4
		syscall
		
		la $a0,CreateSpArC
		li $v0,4
		syscall
	
		la $a0,dspA
		li $v0,4
		syscall
		
		la $a0,dspB
		li $v0,4
		syscall
		
		la $a0,dspC
		li $v0,4
		syscall
		
		la $a0,Exit
		li $v0,4
		syscall
		
		la $a0,Space2
		li $v0,4
		syscall
		
		la $a0,choose
		li $v0,4
		syscall
		
		li $v0,5
		syscall
		
		jr $ra
		
		.data

ReadArrayA:	.asciiz "1. ReadArrayA\n"
ReadArrayB: .asciiz "2. ReadArrayB\n"
CreateSpArA:	.asciiz "3. Create Sparse Array A\n"
CreateSpArB:	.asciiz "4. Create Sparse Array B\n"
CreateSpArC:	.asciiz "5. Create Sparse Array C = A + B\n"
dspA:	.asciiz "6. Display Sparse Array A\n"
dspB:	.asciiz "7. Display Sparse Array B\n"
dspC:	.asciiz "8. Display Sparse Array C\n"
Exit:	.asciiz "0. Exit\n"
Space1:	.asciiz "\n-----------------------------\n"
Space2:	.asciiz "-----------------------------\n"
choose:	.asciiz "Choose? "