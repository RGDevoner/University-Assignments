library ieee;
use ieee.std_logic_1164.all;
entity P1EX1 is
	port(X1, X2, X3,X4,X5: in std_logic;
	f: out std_logic);
end P1EX1;
library ieee;
use ieee.std_logic_1164.all;
entity AND_3 is
	port(in1,in2,in3 : in std_logic;
			out1: out std_logic);
end AND_3;
architecture logicFUNC of AND_3 is
begin
		out1 <= in1 and in2 and in3;
end logicFUNC;
library ieee;
use ieee.std_logic_1164.all;
entity AND_4 is
	port(in1,in2,in3, in4 : in std_logic;
			out1: out std_logic);
end AND_4;
architecture logicFUNC1 of AND_4 is
begin
		out1 <= in1 and in2 and in3 and in4;
end logicFUNC1;
library ieee;
use ieee.std_logic_1164.all;
entity OR_5 is
	port(in1,in2,in3,in4,in5: in std_logic;
			out1: out std_logic);
end OR_5;
architecture logicFUNC2 of OR_5 is
begin
		out1 <= in1 or in2 or in3 or in4 or in5;
end logicFUNC2;
library ieee;
use ieee.std_logic_1164.all;
entity NOT_1 is
	port(in1 : in std_logic;
			out1: out std_logic);
end NOT_1;
architecture logicFUNC3 of NOT_1 is
begin
		out1 <= not in1;
end logicFUNC3;
architecture structural of P1EX1 is
component AND_3
	port (in1,in2,in3:in std_logic;
			out1:out std_logic); 
end component;
component AND_4
	port (in1,in2,in3,in4:in std_logic;
			out1:out std_logic);
end component;
component OR_5
	port (in1,in2,in3,in4,in5:in std_logic;
			out1:out std_logic);
end component;
component NOT_1
	port(in1: in std_logic;
			out1:out std_logic);
end component;
signal NOTX1,NOTX2,NOTX3,NOTX4,NOTX5,S1,S2,S3,S4,S5:std_logic;

begin 
U0:NOT_1 port map(X1 ,NOTX1);
U1:NOT_1 port map(X2,NOTX2);
U2:NOT_1 port map(X3,NOTX3);
U3:NOT_1 port map(X4,NOTX4);
U4:NOT_1 port map(X5,NOTX5);
U5:AND_3 port map(NOTX2,NOTX4,X5,S1);
U6:AND_3 port map(NOTX1,NOTX3,NOTX4,S2);
U7:AND_4 port map(NOTX1,X2,X3,NOTX5,S3);
U8:AND_4 port map(X1,NOTX3,X4,X5,S4);
U9:AND_4 port map(NOTX1,NOTX2,NOTX3,NOTX5,S5);
U10:OR_5 port map(S1,S2,S3,S4,S5,f);
end structural;