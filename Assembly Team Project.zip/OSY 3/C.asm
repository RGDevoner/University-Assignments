		.text
		.globl __start

main:
		
		la $a0,strSpare
		li $v0,4
		syscall
		
		la $a0,arr #base register
		li $a1,4 #size
		
		jal printSparse
		
		li $v0,10
		syscall

printSparse:

		li $t0,1
		move $t1,$a0 
		lw $t2,($t1)			#loads first data of array
		
loop:	

		la $a0,p1
		li $v0,4
		syscall
		
		move $a0,$t2
		li $v0,1
		syscall
		
		add $t1,$t1,4
		lw $t2,($t1)
		
		la $a0,p3
		li $v0,4
		syscall
		
		move $a0,$t2
		li $v0,1
		syscall
		
		add $t0,$t0,2
		add $t1,$t1,4
		lw $t2,($t1)
		
		la $a0,p4
		li $v0,4
		syscall
		
		blt $t0,$a1,loop
		
		jr $ra
		

		.data
arr:	.word 5, 8, 9, 3
strSpare:	.asciiz "Displaying Sparse Array A\n"
p1:	.asciiz "Position: "
p3:	.asciiz " Value: "
p4:		.asciiz "\n"